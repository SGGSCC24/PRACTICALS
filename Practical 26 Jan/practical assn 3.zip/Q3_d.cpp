/*
d)
      1
    1 2 1
  1 2 3 2 1
1 2 3 4 3 2 1
*/

#include<iostream>
using namespace std;

int main(){
    unsigned int n;
    cout<<"ENTER NUMBER OF ROWS: ";
    cin>>n;

    for (int row = 1; row<=n; row++){
        for (int space = n; space>row; space--){
            cout<<"  ";
        }
        for (int i = 1; i <= row*2-1; i++){
            if (i>row){
                cout<<row-(i-row);
            }
            else cout<<i;
            cout<<" ";
        }
        cout<<endl;
    }
    return 0;
}