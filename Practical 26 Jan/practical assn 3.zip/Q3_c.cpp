/*
Q.3 WAP to print the following number pyramids for n rows:
c)
1 2 3 4 5
1 2 3 4
1 2 3
1 2
1
*/

#include<iostream>
using namespace std;

int main(){
    unsigned int n;
    cout<<"ENTER NUMBER OF ROWS: ";
    cin>>n;
    for (int rows=n; rows <= n; rows--){
        for (int i = 1; i <= rows; i++){
            cout<<i<<" ";
        }
        cout<<endl;
    }

    return 0;
}